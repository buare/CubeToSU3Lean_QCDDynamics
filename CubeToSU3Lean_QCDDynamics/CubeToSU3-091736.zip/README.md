# CubeToSU3Lean — complete reproducible project

This package formalises a finite cube / cyclic-difference construction, its
extension to the real Lie algebra `su(3)`, selected global facts about the
matrix group `SU(3)`, and a deliberately limited first layer of classical QCD
kinematics, explicit classical QCD residual equations, and a ledger comparing
dimensionless normalisation with physically calibrated parameters.

The project is designed as an auditable **candidate group-algebra engine**.
It does **not** claim that the eight cube vertices are the eight gluons, or
that the constructed `SU(3)` must be the physical colour group.

## Axiom footprint

Every mathematical result in this project depends on exactly three axioms:

```text
propext, Classical.choice, Quot.sound
```

These are Lean's standard axioms; they are what Mathlib itself rests on.  In
particular the project contains

- no `sorry` and no `admit`,
- no `native_decide`, hence no `Lean.ofReduceBool` — every finite computation
  is run by the kernel, not by compiled code,
- and **no custom axiom inside any mathematical proof**.

Eleven `axiom` declarations do exist, in `PhysicsInputs.lean` (eight) and
`AnomalyLedger.lean` (three).  They record the external physical dictionary,
and no mathematical theorem uses any of them.  This is not a claim to be taken
on trust: run `lake env lean CubeToSU3/Check.lean` and read the
`#print axioms` output.

## Toolchain

- Lean `v4.16.0`
- Mathlib `v4.16.0`
- Exact dependency revisions are pinned in `lake-manifest.json`.

## Build and audit

```bash
lake update
lake exe cache get
lake build
lake env lean CubeToSU3/Check.lean
```

Do not certify a build by filtering for selected success lines. Read the full
output and first confirm that the command exit code is zero and no `error:`
line occurred.

`CubeToSU3.lean` imports every shipped module. `CubeToSU3/Check.lean` samples
all layers with `#print axioms`; its final report deliberately prints the eight
external physics inputs.

## Module map

### Finite core

- `Core.lean` — cyclic difference `D`, traceless 3×3 seed, exact integral
  kernel/image/intersection facts.
- `CrossProduct.lean` — `D v = v × 1` and the derived `D²` identity.
- `Cube.lean` — `Z/3` group algebra, cube graph, bipartite chirality and the
  zero-index no-go.
- `Hexagon.lean` — replacement tests against a six-cycle.
- `ClosedWalks.lean` — closed-walk spectral invariants and their no-go.
- `YouNian.lean` — the two traditional tables as `(Z/2)^3` XOR structures.
- `YouNianGray.lean` — the star order is a cyclic Gray code; the table entry is
  the *rank* of the XOR in that circuit, and 吉凶 is a single Walsh character.
- `YouNianThreeSystems.lean` — 天父卦, 地母卦 and 壺中鬼卦 transcribed in full
  (192 cells).  All three are XOR-only Gray codes; 天父 coincides with 大遊年,
  地母 is the same circuit traversed backwards, 壺中鬼 is its mirror.  The three
  received systems use only two of the six Hamiltonian cycles of `Q₃`.
- `CubeFlavourNoGo.lean` — the cube's rotation group is `S₄`; by Schur's lemma
  an invariant mass matrix is scalar, so an unbroken flavour `S₄` forces three
  degenerate generations.
- `QianKunAxis.lean` — projecting along the 乾-坤 body diagonal sends those two
  vertices to the origin and the other six to a regular hexagon; `D` is the
  generator of the rotation about that axis, and `Core`'s zero-sum plane is the
  root plane.
- `RootMatch.lean` — the structural statement: `D` maps the six non-axis
  vertices bijectively onto the six roots `e_i - e_j` of `A₂`, and
  `[diag h, E] = ⟨D·v, h⟩ · E` — the vector the cube supplies *is* the adjoint
  eigenvalue.  The axis stabiliser acts as the Weyl group does, up to the sign
  of the permutation.

### Candidate physics ledgers

- `Anomalies.lean` — exact anomaly arithmetic for one specified 331-type
  fermion table. The table is input; it is not derived from the cube.
- `Flavour.lean` — machine checks that the declared CKM magnitude tables are
  non-block under every labelling. The alignment-to-block-CKM bridge remains
  unformalised.
- `Rejected.lean` — six recorded rejected routes.
- `PhysicsInputs.lean` — eight explicitly named external assumptions.

### Algebraic and continuous `su(3)`

- `CompactSU3.lean` — Gaussian-integer anti-Hermitian traceless 3×3 lattice,
  eight integer coordinates, bracket closure, and the exact bridge
  `Dg_eq_image_of_core_D`.
- `CompactSU3Real.lean` — real scalar extension and the linear equivalence
  `ℝ^8 ≃ₗ[ℝ] su(3)`; real bracket and naive ODE vector field.
- `Weyl.lean` — finite signed-permutation calculations on the lattice.
- `WeylReal.lean` — group action of `(Z/2)^3 ⋊ S3`, order 48, kernel 2,
  image 24, and extension to real `su(3)`.

### Global `SU(3)` and QCD kinematics

- `SU3Group.lean` — `finrank su(3)=8`; `exp X ∈ SU(3)`; continuity.
- `SU3Global.lean` — topological-group structure and continuous
  one-parameter subgroups.
- `SU3Surjectivity.lean` — constructs a trace-zero logarithm and proves
  exponential surjectivity conditional on `UnitarySpectralTheorem3`.
- `SU3SpectralStage1.lean` … `SU3SpectralStage5.lean` — **discharge that
  premise**.  Mathlib `v4.16.0` has no spectral theorem for normal or unitary
  matrices (no Schur triangulation, no simultaneous diagonalisation), so one is
  built from the Hermitian theorem by the Cayley transform: a phase clearing
  the eigenvalue `-1`, the transform and its Hermiticity, its inversion, the
  transport of the diagonalisation, and the assembly.  `expSU3_surjective` is
  now unconditional.
- `QCDKinematics.lean` — `su(3)`-valued gauge potentials, non-abelian field
  strength, antisymmetry, a nonnegative Euclidean point density, and the
  fundamental colour action.
- `QCDDynamics.lean` — explicit `g_s`, adjoint and quark covariant derivatives,
  Yang--Mills and Dirac residual equations, a pointwise Euclidean QCD density,
  and initial/boundary-value problem data.
- `GaugeTheory.lean` — `Ad g X = g X g†` is a Lie-algebra automorphism of
  `su(3)`.  Deliberately **independent of any base space**: no spacetime, no
  metric, no differentiation appears, so the same block serves a Lorentzian
  theory, a lattice, or a flavour `SU(3)` with no space at all.
- `GaugeGlobal.lean` — for constant `g`, `F(Ad g ∘ A) = Ad g (F A)`.  The one
  analytic input is that `fderiv` commutes with a fixed continuous linear
  equivalence.
- `GaugeLocal.lean` — the Maurer–Cartan form `θ = u ∂u†` of a base-dependent
  `g`, proved anti-Hermitian from unitarity alone.  Its tracelessness is
  carried as an **explicit hypothesis** of `LocalGauge`, because it follows
  from `det g = 1` by Jacobi's formula, which the pinned Mathlib lacks.
- `LatticeGauge.lean` — lattice gauge theory on the cube itself: a connection
  is one group element per directed edge, plaquette holonomy is a product of
  four, and a gauge transformation conjugates it at the base vertex, so its
  trace is an observable.  A pure-gauge connection is flat.
- `LatticeNonFlat.lean` — and one that is not.  Taking the 120° rotation about
  the 乾-坤 diagonal and a sign flip — both elements of the cube's own symmetry
  group — the plaquette holonomy is their commutator `diag(-1,-1,1)`, of trace
  `-1` rather than `3`.  The connection is therefore pure gauge in **no** frame:
  the curvature cannot be removed by any choice of frame at the eight vertices.
- `WilsonAction.lean` — the Wilson action `S = Σ (3 - Re tr W)` over the
  twenty-four (vertex, plane) pairs.  It is gauge invariant, vanishes on flat
  connections, and for the connection above equals `32`: each vertex
  contributes `3 - (-1) = 4` from the `(0,1)` plane, the other two planes
  being flat.  This is the first non-zero gauge-invariant *number* in the
  project — everything before it was an identity, a vanishing no-go, or a
  matrix.
- `AnomalyLedger.lean` — the `X_Q` spectrum `{-1/3,-1/3,2/3}` is forced, the
  split `2+1` is the only anomaly-free one, and all six anomalies of the
  fifteen-field content vanish.  The three dictionary axioms are declared and
  used by nothing.
- `DimensionlessComparison.lean` — proves that a single nonzero scale can be
  divided out of the isolated homogeneous toy flow, while the measured QCD
  coupling changes the relative commutator coefficient.  It encodes the PDG
  2025 central datum `alpha_s(M_Z^2)=0.1180` explicitly as input.

## Exact claim boundary

### Machine checked

1. The original integer `D` is carried unchanged into the Gaussian lattice.
2. The full real vector space of anti-Hermitian traceless complex 3×3 matrices
   is linearly equivalent to eight real coordinates.
3. The commutator closes in this carrier.
4. Exponentials of its elements are special unitary.
5. The declared finite signed-permutation action preserves the bracket.
6. The specified anomaly and CKM tables satisfy the encoded integer claims.
7. `exp : su(3) → SU(3)` is surjective, **unconditionally**; the unitary
   spectral theorem needed for it is built here, not assumed.
8. The six non-axis vertices of the cube, carried by `D`, are the six roots of
   `A₂`, in the structural sense that each is the adjoint eigenvalue of the
   matching generator.
9. Gauge covariance of the field strength under constant gauge transformations,
   and the anti-Hermiticity of the Maurer–Cartan form under local ones.
10. On the cube as a lattice: plaquette holonomy is conjugated by gauge
    transformations, pure-gauge connections are flat, and there exists an
    explicit connection built from the cube's own symmetries that is flat in
    no frame.
11. The Wilson action of that connection is `32`, a gauge-invariant real
    number that no choice of frame can lower.

### Conditional or not yet formalised

1. `ℚ³ = ker D ⊕ im D` with dimensions `1+2`: Core proves the integral
   kernel/image/intersection facts, not this rational direct-sum theorem.
2. Identification of the hand-built signed-permutation group with a formal
   `A₂` root-system in Mathlib's sense.  `RootMatch.lean` proves the six
   vertices are the six roots and that the axis stabiliser acts as the Weyl
   group does; it does not connect to Mathlib's root-system API.
3. Tracelessness of the Maurer–Cartan form of a local gauge transformation.
   It follows from `det g = 1` by Jacobi's formula, and Mathlib `v4.16.0` has
   no derivative of the determinant at all — `Matrix.det` appears nowhere in
   `Mathlib/Analysis/Calculus/`.  Carried as an explicit hypothesis, in the
   same way `UnitarySpectralTheorem3` was carried before it was discharged.
4. Local (base-dependent) gauge covariance of the field strength.  The
   homogeneous part is `GaugeGlobal`; what remains is the cancellation of the
   inhomogeneous residue against the Maurer–Cartan term.
5. A smooth-manifold `LieGroup` instance for `SU(3)`.
6. The flavour alignment theorem connecting `[P₁,H_u]=[P₁,H_d]=0` to a
   block CKM matrix.
7. Experimental provenance and uncertainty modelling for every CKM bound.
8. An action functional and a variational derivation of the Yang–Mills
   equations.  The equations are currently written down as residuals, not
   derived from a spacetime-integrated action.

### Physical dictionary, not a theorem

- eight cube vertices `=` eight gluons;
- this candidate `SU(3)` `=` the physical colour group;
- Lorentz chirality, weak direction, particle assignments and 331 parameter
  `β`;
- measured couplings, masses and scale setting.

## QCD scope

`QCDKinematics.lean` remains the unit-normalised kinematic layer.
`QCDDynamics.lean` adds explicit `g_s`, colour--spin quark fields, Dirac and
Yang--Mills residual equations, and initial/boundary data.

The gauge modules have since supplied part of what that layer was missing.
`GaugeGlobal` proves covariance of the field strength under constant gauge
transformations, and `GaugeLocal` constructs the Maurer–Cartan form that the
local transformation law needs.  Local covariance itself is not yet proved.

What is still absent: a principal bundle, a Minkowski metric, Clifford
relations on the gamma matrices (`DiracEquation` currently accepts *any* four
matrices), a variational proof deriving the equations from a
spacetime-integrated action, Grassmann fields, gauge fixing and ghosts,
quantisation, renormalisation, confinement and hadron spectroscopy.

A note on why the continuum side stops where it does.  `Spacetime` is
`Fin 4 → ℝ`, which is contractible, and over a contractible base every
principal bundle is trivial — no construction there can produce a non-zero
Chern class.  Mathlib has no principal bundles and no characteristic classes,
so that route is closed.  The lattice route is not, which is why
`LatticeGauge` and `LatticeNonFlat` exist: on a lattice, holonomy is a finite
product of group elements and non-triviality is a decidable statement.

## Dimensionless-versus-physical gap

The new comparison makes the boundary exact.

1. The finite algebra supplies a dimensionless direction
   `adDVec : R^8 -> R^8` and unit-normalised commutator structure.
2. Multiplying the isolated homogeneous ODE by one nonzero `kappa` only sets
   the clock: `kappa^-1 • calibratedRHS kappa c = naiveRHS c`.
3. In QCD, `g_s` is not merely that clock. It changes the relative coefficient
   of `dA` and `[A,A]`:

   `F_g - F_1 = (g_s - 1) [A_mu,A_nu]`.

4. The PDG 2025 input `alpha_s(M_Z^2)=0.1180 +/- 0.0009` corresponds to
   `g_s(M_Z) ~= 1.2177`, not the hidden unit value.  The non-abelian amplitude
   coefficient is therefore about 21.8% above the toy normalisation at that
   reference scale.  This number is an inserted experimental calibration, not
   a theorem of the cube.
5. A unique physical solution additionally needs quark masses, gamma/metric
   conventions, sources or coupled quark currents, and initial/boundary data.
   Quantum predictions further need renormalisation and a state/observable
   prescription.

The scientifically correct workflow is therefore:

```text
finite structure → candidate su(3) → declared physical dictionary
                 → insert measured inputs → derive other observables
                 → compare with experiment → accept, constrain, or reject
```

This permits genuine interaction with experimental data without pretending
that a successful comparison retrospectively proves the physical dictionary.

## Verification records

- `VERIFICATION.md` — current audit instructions and status.
- `verification/build-weyl-real-v8.log` — supplied historical successful build
  through `WeylReal` (UTF-16LE log; linter warnings are non-fatal).
- `verification/build-weyl-real-v8.utf8.log` — the same build record converted
  to UTF-8 for convenient reading.
- `verification/VERIFICATION_v11_historical.md` — earlier 52-line audit.
- `verification/Check_v11_original.lean` — earlier central audit before the
  continuous/global/QCD modules were added.
- `README.original.md` — supplied earlier README preserved for comparison.
