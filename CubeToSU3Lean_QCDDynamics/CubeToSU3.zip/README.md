# CubeToSU3Lean — complete reproducible project

This package formalises a finite cube / cyclic-difference construction, its
extension to the real Lie algebra `su(3)`, selected global facts about the
matrix group `SU(3)`, and a deliberately limited first layer of classical QCD
kinematics, explicit classical QCD residual equations, and a ledger comparing
dimensionless normalisation with physically calibrated parameters.

The project is designed as an auditable **candidate group-algebra engine**.
It does **not** claim that the eight cube vertices are the eight gluons, or
that the constructed `SU(3)` must be the physical colour group.

## Toolchain

- Lean `v4.16.0`
- Mathlib `v4.16.0`
- Exact dependency revisions are pinned in `lake-manifest.json`.

## Build and audit

```bash
lake update
lake exe cache get
lake build
lake env lean CubeToSU3/Check.lean
```

Do not certify a build by filtering for selected success lines. Read the full
output and first confirm that the command exit code is zero and no `error:`
line occurred.

`CubeToSU3.lean` imports every shipped module. `CubeToSU3/Check.lean` samples
all layers with `#print axioms`; its final report deliberately prints the eight
external physics inputs.

## Module map

### Finite core

- `Core.lean` — cyclic difference `D`, traceless 3×3 seed, exact integral
  kernel/image/intersection facts.
- `CrossProduct.lean` — `D v = v × 1` and the derived `D²` identity.
- `Cube.lean` — `Z/3` group algebra, cube graph, bipartite chirality and the
  zero-index no-go.
- `Hexagon.lean` — replacement tests against a six-cycle.
- `ClosedWalks.lean` — closed-walk spectral invariants and their no-go.
- `YouNian.lean` — the two traditional tables as `(Z/2)^3` XOR structures.

### Candidate physics ledgers

- `Anomalies.lean` — exact anomaly arithmetic for one specified 331-type
  fermion table. The table is input; it is not derived from the cube.
- `Flavour.lean` — machine checks that the declared CKM magnitude tables are
  non-block under every labelling. The alignment-to-block-CKM bridge remains
  unformalised.
- `Rejected.lean` — six recorded rejected routes.
- `PhysicsInputs.lean` — eight explicitly named external assumptions.

### Algebraic and continuous `su(3)`

- `CompactSU3.lean` — Gaussian-integer anti-Hermitian traceless 3×3 lattice,
  eight integer coordinates, bracket closure, and the exact bridge
  `Dg_eq_image_of_core_D`.
- `CompactSU3Real.lean` — real scalar extension and the linear equivalence
  `ℝ^8 ≃ₗ[ℝ] su(3)`; real bracket and naive ODE vector field.
- `Weyl.lean` — finite signed-permutation calculations on the lattice.
- `WeylReal.lean` — group action of `(Z/2)^3 ⋊ S3`, order 48, kernel 2,
  image 24, and extension to real `su(3)`.

### Global `SU(3)` and QCD kinematics

- `SU3Group.lean` — `finrank su(3)=8`; `exp X ∈ SU(3)`; continuity.
- `SU3Global.lean` — topological-group structure and continuous
  one-parameter subgroups.
- `SU3Surjectivity.lean` — constructs a trace-zero logarithm and proves
  exponential surjectivity **conditional on** `UnitarySpectralTheorem3`.
- `QCDKinematics.lean` — `su(3)`-valued gauge potentials, non-abelian field
  strength, antisymmetry, a nonnegative Euclidean point density, and the
  fundamental colour action.
- `QCDDynamics.lean` — explicit `g_s`, adjoint and quark covariant derivatives,
  Yang--Mills and Dirac residual equations, a pointwise Euclidean QCD density,
  and initial/boundary-value problem data.
- `DimensionlessComparison.lean` — proves that a single nonzero scale can be
  divided out of the isolated homogeneous toy flow, while the measured QCD
  coupling changes the relative commutator coefficient.  It encodes the PDG
  2025 central datum `alpha_s(M_Z^2)=0.1180` explicitly as input.

## Exact claim boundary

### Machine checked

1. The original integer `D` is carried unchanged into the Gaussian lattice.
2. The full real vector space of anti-Hermitian traceless complex 3×3 matrices
   is linearly equivalent to eight real coordinates.
3. The commutator closes in this carrier.
4. Exponentials of its elements are special unitary.
5. The declared finite signed-permutation action preserves the bracket.
6. The specified anomaly and CKM tables satisfy the encoded integer claims.

### Conditional or not yet formalised

1. `ℚ³ = ker D ⊕ im D` with dimensions `1+2`: Core proves the integral
   kernel/image/intersection facts, not this rational direct-sum theorem.
2. Identification of the hand-built signed-permutation group with the graph
   automorphism group `Aut(Q₃)` and of `Perm3` with a formal `A₂` root-system
   Weyl group.
3. Unconditional surjectivity of `exp : su(3) → SU(3)`; the current theorem
   has the explicit premise `UnitarySpectralTheorem3`.
4. A smooth-manifold `LieGroup` instance for `SU(3)`.
5. The flavour alignment theorem connecting `[P₁,H_u]=[P₁,H_d]=0` to a
   block CKM matrix.
6. Experimental provenance and uncertainty modelling for every CKM bound.

### Physical dictionary, not a theorem

- eight cube vertices `=` eight gluons;
- this candidate `SU(3)` `=` the physical colour group;
- Lorentz chirality, weak direction, particle assignments and 331 parameter
  `β`;
- measured couplings, masses and scale setting.

## QCD scope

`QCDKinematics.lean` remains the unit-normalised kinematic layer.
`QCDDynamics.lean` now adds explicit `g_s`, colour--spin quark fields, Dirac and
Yang--Mills residual equations, and initial/boundary data.  This is still a
classical Euclidean-coordinate prototype: it does not yet contain a principal
bundle, finite local gauge transformations, a Minkowski metric, a variational
proof deriving the equations from a spacetime-integrated action, Grassmann
fields, gauge fixing and ghosts, quantisation, renormalisation, confinement or
hadron spectroscopy.

## Dimensionless-versus-physical gap

The new comparison makes the boundary exact.

1. The finite algebra supplies a dimensionless direction
   `adDVec : R^8 -> R^8` and unit-normalised commutator structure.
2. Multiplying the isolated homogeneous ODE by one nonzero `kappa` only sets
   the clock: `kappa^-1 • calibratedRHS kappa c = naiveRHS c`.
3. In QCD, `g_s` is not merely that clock. It changes the relative coefficient
   of `dA` and `[A,A]`:

   `F_g - F_1 = (g_s - 1) [A_mu,A_nu]`.

4. The PDG 2025 input `alpha_s(M_Z^2)=0.1180 +/- 0.0009` corresponds to
   `g_s(M_Z) ~= 1.2177`, not the hidden unit value.  The non-abelian amplitude
   coefficient is therefore about 21.8% above the toy normalisation at that
   reference scale.  This number is an inserted experimental calibration, not
   a theorem of the cube.
5. A unique physical solution additionally needs quark masses, gamma/metric
   conventions, sources or coupled quark currents, and initial/boundary data.
   Quantum predictions further need renormalisation and a state/observable
   prescription.

The scientifically correct workflow is therefore:

```text
finite structure → candidate su(3) → declared physical dictionary
                 → insert measured inputs → derive other observables
                 → compare with experiment → accept, constrain, or reject
```

This permits genuine interaction with experimental data without pretending
that a successful comparison retrospectively proves the physical dictionary.

## Verification records

- `VERIFICATION.md` — current audit instructions and status.
- `verification/build-weyl-real-v8.log` — supplied historical successful build
  through `WeylReal` (UTF-16LE log; linter warnings are non-fatal).
- `verification/build-weyl-real-v8.utf8.log` — the same build record converted
  to UTF-8 for convenient reading.
- `verification/VERIFICATION_v11_historical.md` — earlier 52-line audit.
- `verification/Check_v11_original.lean` — earlier central audit before the
  continuous/global/QCD modules were added.
- `README.original.md` — supplied earlier README preserved for comparison.
